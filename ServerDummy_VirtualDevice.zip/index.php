<?php 
header('Access-Control-Allow-Origin: '.$_SERVER['HTTP_ORIGIN']);
header("Content-Type: text/plain");
echo "00F000000000000000000000";
?>